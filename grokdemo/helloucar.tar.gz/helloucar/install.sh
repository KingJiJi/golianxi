install -d /usr/bin
install -d /usr/lib
install -d /usr/include
install -m 755 grok /usr/bin
install -m 755 discogrok /usr/bin
install -m 644 libgrok.so /usr/lib
for header in grok.h grok_pattern.h grok_capture.h grok_capture_xdr.h grok_match.h grok_logging.h grok_discover.h grok_version.h; do \
		install -m 644 $header /usr/include; \
	done
install -d /usr/share/grok
install -d /usr/share/grok/patterns
install patterns/base /usr/share/grok/patterns/
